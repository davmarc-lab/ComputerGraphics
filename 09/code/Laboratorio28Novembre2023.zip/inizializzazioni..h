void INIT_SHADER(void);
void INIT_VAO(void);
void INIT_VAO_Text(void);
void INIT_CAMERA_PROJECTION(void);
void INIT_Illuminazione();
