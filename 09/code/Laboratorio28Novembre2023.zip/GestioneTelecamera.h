//Movimento della telecamera
void moveCameraForward(void);
void moveCameraBack(void);
void moveCameraLeft(void);
void moveCameraRight(void);
void moveCameraUp(void);
void moveCameraDown(void);
void my_passive_mouse(int xpos, int ypos);

