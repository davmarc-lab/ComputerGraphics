#include "Strutture.h"
void crea_VAO_Vector(Mesh * mesh);
void crea_VAO_Vector_MeshObj(MeshObj* mesh);
